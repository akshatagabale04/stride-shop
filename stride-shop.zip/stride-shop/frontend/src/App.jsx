import { useEffect, useMemo, useState } from "react";
import { API } from "./config.js";

const rupees = (paise) => "₹" + (paise / 100).toLocaleString("en-IN", { minimumFractionDigits: 0 });
const CATS = ["all", "running", "trail", "casual", "training"];

export default function App() {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState("all");
  const [cart, setCart] = useState({});            // productId -> quantity
  const [view, setView] = useState("shop");        // shop | cart | done
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");
  const [placing, setPlacing] = useState(false);
  const [order, setOrder] = useState(null);

  useEffect(() => {
    setLoading(true); setError("");
    const q = category === "all" ? "" : `?category=${category}`;
    fetch(`${API}/api/products${q}`)
      .then((r) => { if (!r.ok) throw new Error(); return r.json(); })
      .then(setProducts)
      .catch(() => setError("Can't reach the shop right now. Check that the gateway is running on port 8080."))
      .finally(() => setLoading(false));
  }, [category]);

  const known = rememberProducts(products);
  const lines = useMemo(() => Object.entries(cart).map(([id, qty]) => ({ p: known.get(id), qty })).filter((l) => l.p), [cart, products]);
  const total = lines.reduce((s, l) => s + l.p.pricePaise * l.qty, 0);
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const add = (id) => setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
  const setQty = (id, q) => setCart((c) => { const n = { ...c }; q <= 0 ? delete n[id] : (n[id] = q); return n; });

  async function checkout(e) {
    e.preventDefault(); setPlacing(true); setError("");
    try {
      const res = await fetch(`${API}/api/orders`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, items: lines.map((l) => ({ productId: l.p.id, quantity: l.qty })) }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 201) { setOrder(data); setCart({}); setView("done"); }
      else setError(data.failureReason || "We couldn't place your order. Nothing was charged.");
    } catch { setError("Can't reach the shop right now. Try again in a moment."); }
    setPlacing(false);
  }

  return (
    <>
      <header className="bar">
        <button className="logo" onClick={() => setView("shop")}>Stride</button>
        <button className="cartbtn" onClick={() => setView("cart")} aria-label={`Cart, ${count} items`}>Cart <b>{count}</b></button>
      </header>

      {view === "shop" && (
        <main>
          <section className="hero">
            <h1>Shoes, measured in kilometres.</h1>
            <p>Pick a category and add what you need. Stock is held for you the moment you pay.</p>
          </section>
          <nav className="tabs" aria-label="Categories">
            {CATS.map((c) => <button key={c} className={c === category ? "on" : ""} onClick={() => setCategory(c)}>{c}</button>)}
          </nav>
          {error && <p className="msg err" role="alert">{error}</p>}
          {loading ? <p className="msg">Loading shoes…</p> : (
            <ul className="grid">
              {products.map((p) => (
                <li key={p.id} className="card">
                  <div className={`swatch c${p.id % 8}`} aria-hidden="true"><span>{p.name}</span></div>
                  <h2>{p.name}</h2>
                  <p className="desc">{p.description}</p>
                  <div className="row"><strong>{rupees(p.pricePaise)}</strong><button onClick={() => add(p.id)}>Add to cart</button></div>
                </li>
              ))}
            </ul>
          )}
          {!loading && !error && products.length === 0 && <p className="msg">No shoes in this category yet.</p>}
        </main>
      )}

      {view === "cart" && (
        <main className="narrow">
          <h1>Your cart</h1>
          {lines.length === 0 ? <p className="msg">Your cart is empty. <button className="link" onClick={() => setView("shop")}>Browse shoes</button></p> : (
            <>
              <ul className="lines">
                {lines.map(({ p, qty }) => (
                  <li key={p.id}><span>{p.name}</span>
                    <span className="qty"><button aria-label="Decrease" onClick={() => setQty(p.id, qty - 1)}>−</button>{qty}<button aria-label="Increase" onClick={() => setQty(p.id, qty + 1)}>+</button></span>
                    <b>{rupees(p.pricePaise * qty)}</b></li>
                ))}
              </ul>
              <p className="total">Total <b>{rupees(total)}</b></p>
              <form onSubmit={checkout}>
                <label>Email for your receipt<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" /></label>
                {error && <p className="msg err" role="alert">{error}</p>}
                <button className="primary" disabled={placing}>{placing ? "Placing order…" : `Pay ${rupees(total)}`}</button>
              </form>
            </>
          )}
        </main>
      )}

      {view === "done" && order && (
        <main className="narrow">
          <h1>Order confirmed</h1>
          <p>We're emailing your receipt to <b>{order.email}</b>.</p>
          <p className="mono">Order {order.id}</p>
          <ul className="lines">{order.items.map((i) => <li key={i.productId}><span>{i.name} × {i.quantity}</span><b>{rupees(i.unitPaise * i.quantity)}</b></li>)}</ul>
          <p className="total">Paid <b>{rupees(order.totalPaise)}</b></p>
          <button className="primary" onClick={() => setView("shop")}>Keep shopping</button>
        </main>
      )}
    </>
  );
}

// Remember every product we've seen so cart lines survive switching categories.
const seen = new Map();
function rememberProducts(products) { products.forEach((p) => seen.set(String(p.id), p)); return seen; }
