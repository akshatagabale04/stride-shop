// Single place the browser learns where the backend lives: the API Gateway.
export const API = import.meta.env.VITE_API_URL || "http://localhost:8080";
