CREATE DATABASE catalog_db; CREATE DATABASE order_db; CREATE DATABASE payment_db; CREATE DATABASE inventory_db;
