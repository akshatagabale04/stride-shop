package shop;
import jakarta.persistence.*;
import java.time.Instant;
import java.util.*;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.*;

@SpringBootApplication @RestController @RequestMapping("/orders")
public class OrderApp {
  @Embeddable public static class Line { public Long productId; public String name; public int quantity; public long unitPaise; }
  @Entity @Table(name = "orders")
  public static class Order {
    @Id public UUID id = UUID.randomUUID();
    public String email, status = "PENDING", failureReason;
    public long totalPaise; public Instant createdAt = Instant.now();
    @ElementCollection(fetch = FetchType.EAGER) @CollectionTable(name = "order_items") public List<Line> items = new ArrayList<>();
  }
  public interface Repo extends JpaRepository<Order, UUID> { List<Order> findByEmailOrderByCreatedAtDesc(String e); }
  public record ItemReq(Long productId, int quantity) {}
  public record OrderReq(String email, List<ItemReq> items) {}
  record Product(Long id, String name, long pricePaise) {}

  private final Repo repo; private final RabbitTemplate mq;
  private final RestClient http = RestClient.create();
  @Value("${catalog.url}") String catalog; @Value("${payment.url}") String payment; @Value("${inventory.url}") String inventory;
  OrderApp(Repo r, RabbitTemplate mq) { repo = r; this.mq = mq; }

  @Bean MessageConverter json() { return new Jackson2JsonMessageConverter(); }
  @Bean TopicExchange orders() { return new TopicExchange("orders"); }

  @PostMapping public ResponseEntity<Order> place(@RequestBody OrderReq req) {
    if (req.email() == null || req.items() == null || req.items().isEmpty()) return ResponseEntity.badRequest().build();
    Order o = new Order(); o.email = req.email();
    for (ItemReq i : req.items()) {                       // prices always come from the catalog, never the browser
      Product p = http.get().uri(catalog + "/products/" + i.productId()).retrieve().body(Product.class);
      Line l = new Line(); l.productId = p.id(); l.name = p.name(); l.quantity = i.quantity(); l.unitPaise = p.pricePaise();
      o.items.add(l); o.totalPaise += l.unitPaise * l.quantity;
    }
    repo.save(o);                                          // 1. PENDING

    Map<?,?> pay = http.post().uri(payment + "/payments").body(Map.of("orderId", o.id, "amountPaise", o.totalPaise)).retrieve().body(Map.class);
    if (!"PAID".equals(pay.get("status"))) return finish(o, "FAILED", "Payment declined", HttpStatus.PAYMENT_REQUIRED);   // 2. payment

    List<Line> reserved = new ArrayList<>();               // 3. reserve stock, undo on any failure
    for (Line l : o.items) {
      try { http.post().uri(inventory + "/inventory/reserve").body(Map.of("productId", l.productId, "quantity", l.quantity)).retrieve().toBodilessEntity(); reserved.add(l); }
      catch (RestClientResponseException e) {
        reserved.forEach(r -> http.post().uri(inventory + "/inventory/release").body(Map.of("productId", r.productId, "quantity", r.quantity)).retrieve().toBodilessEntity());
        return finish(o, "FAILED", l.name + " is out of stock (payment will be refunded)", HttpStatus.CONFLICT);
      }
    }
    o.status = "CONFIRMED"; repo.save(o);                  // 4. confirm
    mq.convertAndSend("orders", "order.confirmed", Map.of("orderId", o.id, "email", o.email, "totalPaise", o.totalPaise)); // 5. async event
    return ResponseEntity.status(HttpStatus.CREATED).body(o);
  }
  private ResponseEntity<Order> finish(Order o, String status, String why, HttpStatus code) { o.status = status; o.failureReason = why; repo.save(o); return ResponseEntity.status(code).body(o); }

  @GetMapping("/{id}") public ResponseEntity<Order> get(@PathVariable UUID id) { return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
  @GetMapping public List<Order> byEmail(@RequestParam String email) { return repo.findByEmailOrderByCreatedAtDesc(email); }
  public static void main(String[] a) { SpringApplication.run(OrderApp.class, a); }
}
