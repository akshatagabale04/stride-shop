package shop;
import java.util.Map;
import org.slf4j.*;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.converter.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/** Consumes order.confirmed from the event bus and "sends" the receipt (logged; swap in JavaMail/SES for real email). */
@SpringBootApplication
public class NotificationApp {
  static final Logger log = LoggerFactory.getLogger(NotificationApp.class);
  @Bean MessageConverter json() { return new Jackson2JsonMessageConverter(); }
  @Bean TopicExchange orders() { return new TopicExchange("orders"); }
  @Bean Queue q() { return new Queue("notifications.order-confirmed", true); }
  @Bean Binding b(Queue q, TopicExchange orders) { return BindingBuilder.bind(q).to(orders).with("order.confirmed"); }

  @RabbitListener(queues = "notifications.order-confirmed")
  public void onConfirmed(Map<String, Object> e) {
    long paise = ((Number) e.get("totalPaise")).longValue();
    log.info("EMAIL to {}: order {} confirmed, total Rs {}.{}", e.get("email"), e.get("orderId"), paise / 100, String.format("%02d", paise % 100));
  }
  public static void main(String[] a) { SpringApplication.run(NotificationApp.class, a); }
}
