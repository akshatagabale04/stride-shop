package shop;
import jakarta.persistence.*;
import java.util.*;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.http.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@SpringBootApplication @RestController @RequestMapping("/inventory")
public class InventoryApp {
  @Entity @Table(name = "stock")
  public static class Stock { @Id public Long productId; public int onHand, reserved; public Stock() {} Stock(Long id, int n){productId=id;onHand=n;} }
  public interface Repo extends JpaRepository<Stock, Long> {
    // Atomic guard from the architecture: only decrement when enough stock is on hand.
    @Modifying @Transactional
    @Query("update Stock s set s.onHand = s.onHand - :q, s.reserved = s.reserved + :q where s.productId = :id and s.onHand >= :q")
    int reserve(@Param("id") Long id, @Param("q") int q);
    @Modifying @Transactional
    @Query("update Stock s set s.onHand = s.onHand + :q, s.reserved = s.reserved - :q where s.productId = :id and s.reserved >= :q")
    int release(@Param("id") Long id, @Param("q") int q);
  }
  public record Req(Long productId, int quantity) {}
  private final Repo repo;
  InventoryApp(Repo r) { repo = r; }

  @PostMapping("/reserve") public ResponseEntity<Map<String,Object>> reserve(@RequestBody Req r) {
    return repo.reserve(r.productId(), r.quantity()) == 1 ? ResponseEntity.ok(Map.of("reserved", true))
      : ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("reserved", false, "error", "Out of stock"));
  }
  @PostMapping("/release") public Map<String,Object> release(@RequestBody Req r) { return Map.of("released", repo.release(r.productId(), r.quantity()) == 1); }
  @GetMapping("/{id}") public ResponseEntity<Stock> get(@PathVariable Long id) { return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }

  @Bean CommandLineRunner seed() { return a -> { if (repo.count() == 0) for (long i = 1; i <= 8; i++) repo.save(new Stock(i, 25)); }; }
  public static void main(String[] a) { SpringApplication.run(InventoryApp.class, a); }
}
