# Stride – e-commerce reference app (from the "E-Commerce Order Flow Architecture" PDF)

React → API Gateway (:8080) → Spring Boot services → PostgreSQL (database per service) + RabbitMQ event bus.

| Service | Port | Owns | Role |
|---|---|---|---|
| gateway | 8080 | – | Single public entry, routes `/api/products`, `/api/orders`, CORS |
| catalog-service | 8081 | catalog_db | Products, `GET /products?category=` |
| order-service | 8082 | order_db | Orchestrates PENDING → payment → stock → CONFIRMED, publishes `order.confirmed` |
| payment-service | 8083 | payment_db | Mock charge → PAID / FAILED (> ₹5,00,000 fails) |
| inventory-service | 8084 | inventory_db | Atomic reserve: `WHERE on_hand >= qty` |
| notification-service | 8085 | – | Consumes `order.confirmed`, logs the receipt email |

## Run everything
    docker compose up --build        # open http://localhost:3000  (RabbitMQ UI: :15672, guest/guest)
    docker compose logs -f notification-service   # watch the receipt "email"

## Run for development
    docker compose up postgres rabbitmq -d
    mvn -q -DskipTests install && for m in catalog inventory payment order notification; do (cd $m-service && mvn spring-boot:run &) ; done; (cd gateway && mvn spring-boot:run &)
    cd frontend && npm install && npm run dev        # http://localhost:3000

## Try the failure paths
- Out of stock: each product starts with 25 units; order 26.
- Payment declined: cart total above ₹5,00,000 (e.g. 1 × Tempo Carbon ×  6).

## Not included yet (next steps)
JWT auth at the gateway, user-service/cart-service (cart lives in the browser for now), real payment provider, payment refunds, outbox pattern, tests.
