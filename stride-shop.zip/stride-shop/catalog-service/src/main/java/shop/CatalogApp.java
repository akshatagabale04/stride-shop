package shop;
import jakarta.persistence.*;
import java.util.List;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@SpringBootApplication @RestController @RequestMapping("/products")
public class CatalogApp {
  @Entity @Table(name = "products")
  public static class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String name, category, description, imageUrl;
    public long pricePaise;
    public Product() {}
    Product(String n, String c, String d, long p) { name=n; category=c; description=d; pricePaise=p; }
  }
  public interface Repo extends JpaRepository<Product, Long> { List<Product> findByCategoryIgnoreCase(String c); }

  private final Repo repo;
  CatalogApp(Repo repo) { this.repo = repo; }

  @GetMapping public List<Product> list(@RequestParam(required = false) String category) {
    return category == null || category.isBlank() ? repo.findAll() : repo.findByCategoryIgnoreCase(category);
  }
  @GetMapping("/{id}") public ResponseEntity<Product> get(@PathVariable Long id) {
    return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
  }

  @Bean CommandLineRunner seed() { return a -> { if (repo.count() > 0) return;
    repo.saveAll(List.of(
      new Product("Aero Pace 2", "running", "Featherweight daily trainer with a springy foam midsole.", 249900),
      new Product("Tempo Carbon", "running", "Plated race shoe built for fast 10K to marathon.", 899900),
      new Product("Trail Ridge", "trail", "Aggressive lugs and a rock plate for loose, steep ground.", 549900),
      new Product("Summit GTX", "trail", "Waterproof trail shoe for wet, cold mornings.", 649900),
      new Product("Court Classic", "casual", "Leather low-top that goes with everything.", 349900),
      new Product("Canvas Lo", "casual", "Vulcanised canvas sneaker in a washed finish.", 199900),
      new Product("Studio Flex", "training", "Flat, stable platform for lifting and HIIT.", 429900),
      new Product("Recovery Slide", "training", "Cushioned slide for post-workout feet.", 149900))); }; }
  public static void main(String[] a) { SpringApplication.run(CatalogApp.class, a); }
}
