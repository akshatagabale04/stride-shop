package shop;
import jakarta.persistence.*;
import java.util.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.*;

/** Mock payment gateway: charges succeed unless the amount is over 5,00,000 rupees (to demo FAILED). */
@SpringBootApplication @RestController @RequestMapping("/payments")
public class PaymentApp {
  @Entity @Table(name = "payments")
  public static class Payment { @Id public UUID id = UUID.randomUUID(); public UUID orderId; public long amountPaise; public String status; }
  public interface Repo extends JpaRepository<Payment, UUID> {}
  public record Req(UUID orderId, long amountPaise) {}
  private final Repo repo;
  PaymentApp(Repo r) { repo = r; }

  @PostMapping public Map<String,Object> charge(@RequestBody Req r) {
    Payment p = new Payment(); p.orderId = r.orderId(); p.amountPaise = r.amountPaise();
    p.status = r.amountPaise() > 50_000_000L ? "FAILED" : "PAID";
    repo.save(p);
    return Map.of("paymentId", p.id, "status", p.status);
  }
  public static void main(String[] a) { SpringApplication.run(PaymentApp.class, a); }
}
